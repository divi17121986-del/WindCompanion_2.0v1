package ru.windcompanion

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.tasks.await
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

class WindRefreshWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val ctx = applicationContext
        return try {
            val coords = findCoords()
            if (coords == null) {
                val (short, details) = locationProblem()
                WindStore.saveStatus(ctx, short, details)
                WindUpdate.requestAll(ctx)
                return Result.retry()
            }
            WindStore.saveCoords(ctx, coords.first, coords.second)
            val reading = fetchWeather(coords.first, coords.second)
            WindStore.save(ctx, reading)
            WindStore.clearStatus(ctx)
            WindUpdate.requestAll(ctx)
            Result.success()
        } catch (e: java.io.IOException) {
            WindStore.saveStatus(ctx, "Сеть", "Сеть: ${e.message ?: e.javaClass.simpleName}")
            WindUpdate.requestAll(ctx)
            Result.retry()
        } catch (e: Exception) {
            WindStore.saveStatus(ctx, "Ошибка", "Ошибка: ${e.javaClass.simpleName} ${e.message ?: ""}".trim())
            WindUpdate.requestAll(ctx)
            Result.retry()
        }
    }

    private fun granted(p: String) = ContextCompat.checkSelfPermission(
        applicationContext, p
    ) == PackageManager.PERMISSION_GRANTED

    private fun hasLocationPermission(): Boolean {
        if (!granted(Manifest.permission.ACCESS_FINE_LOCATION) &&
            !granted(Manifest.permission.ACCESS_COARSE_LOCATION)) return false
        return Build.VERSION.SDK_INT < 29 ||
            granted(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
    }

    private fun locationProblem(): Pair<String, String> {
        if (!granted(Manifest.permission.ACCESS_FINE_LOCATION) &&
            !granted(Manifest.permission.ACCESS_COARSE_LOCATION))
            return "Права" to "Нет доступа к геолокации"
        if (Build.VERSION.SDK_INT >= 29 && !granted(Manifest.permission.ACCESS_BACKGROUND_LOCATION))
            return "Права" to "Выберите «Разрешить всегда» для геолокации"
        return "GPS" to "Нет геопозиции. Включите геолокацию на часах"
    }

    /** Последняя известная → свежая (быстрая, до 20 с) → сохранённая прошлая. */
    private suspend fun findCoords(): Pair<Double, Double>? {
        if (hasLocationPermission()) {
            val client = LocationServices.getFusedLocationProviderClient(applicationContext)
            var loc: Location? = runCatching { client.lastLocation.await() }.getOrNull()
            if (loc == null) {
                loc = withTimeoutOrNull(20_000) {
                    runCatching {
                        client.getCurrentLocation(
                            Priority.PRIORITY_BALANCED_POWER_ACCURACY,
                            CancellationTokenSource().token
                        ).await()
                    }.getOrNull()
                }
            }
            if (loc != null) return loc.latitude to loc.longitude
        }
        return WindStore.readCoords(applicationContext)
    }

    /** Один запрос: current + hourly + daily. */
    private fun fetchWeather(lat: Double, lon: Double): WeatherReading {
        val url = URL(
            "https://api.open-meteo.com/v1/forecast" +
                "?latitude=$lat&longitude=$lon" +
                "&current=temperature_2m,apparent_temperature,relative_humidity_2m," +
                "wind_speed_10m,wind_direction_10m,wind_gusts_10m,pressure_msl," +
                "cloud_cover,precipitation" +
                "&hourly=dew_point_2m,precipitation_probability,uv_index,visibility,cape,weather_code" +
                "&daily=sunrise,sunset,daylight_duration" +
                "&wind_speed_unit=ms&timezone=auto&forecast_days=2"
        )
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 12000
            readTimeout = 12000
            setRequestProperty("Accept", "application/json")
        }
        try {
            val code = connection.responseCode
            if (code !in 200..299) throw java.io.IOException("HTTP $code")
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            return parse(JSONObject(body))
        } finally {
            connection.disconnect()
        }
    }

    private fun parse(root: JSONObject): WeatherReading {
        val cur = root.getJSONObject("current")
        val hourly = root.getJSONObject("hourly")
        val daily = root.getJSONObject("daily")
        val offsetMs = root.optLong("utc_offset_seconds", 0L) * 1000L

        // Индекс текущего часа в hourly: "2026-11-18T18:45" -> "2026-11-18T18"
        val hourPrefix = cur.getString("time").take(13)
        val times = hourly.getJSONArray("time")
        var idx = 0
        for (i in 0 until times.length()) {
            if (times.getString(i).startsWith(hourPrefix)) { idx = i; break }
        }

        fun h(name: String): Double = hourly.optJSONArray(name)?.optDouble(idx, 0.0)
            ?.takeIf { !it.isNaN() } ?: 0.0

        val precipProb = h("precipitation_probability").toInt()
        val code = h("weather_code").toInt()
        val cape = h("cape")
        // В Open-Meteo нет прямой вероятности грозы — оценка по коду погоды и CAPE.
        val thunder = if (code in 95..99) maxOf(precipProb, 70)
        else minOf(precipProb, (cape / 30.0).toInt()).coerceIn(0, 100)

        val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
        fun day(name: String, i: Int): Long {
            val arr: JSONArray = daily.getJSONArray(name)
            val j = if (i < arr.length()) i else arr.length() - 1
            return (fmt.parse(arr.getString(j))?.time ?: 0L) - offsetMs
        }

        return WeatherReading(
            temperature = cur.getDouble("temperature_2m"),
            feelsLike = cur.getDouble("apparent_temperature"),
            humidity = cur.getDouble("relative_humidity_2m").toInt(),
            dewPoint = h("dew_point_2m"),
            windMs = cur.getDouble("wind_speed_10m"),
            windDir = cur.getDouble("wind_direction_10m").toInt().mod(360),
            gustMs = cur.getDouble("wind_gusts_10m"),
            pressureHpa = cur.getDouble("pressure_msl"),
            cloud = cur.getDouble("cloud_cover").toInt(),
            precipProb = precipProb,
            precipMm = cur.getDouble("precipitation"),
            uv = h("uv_index"),
            visibilityM = h("visibility"),
            thunderProb = thunder,
            sunrise0 = day("sunrise", 0), sunset0 = day("sunset", 0),
            sunrise1 = day("sunrise", 1), sunset1 = day("sunset", 1),
            daylightSec = daily.getJSONArray("daylight_duration").getDouble(0).toInt(),
            updatedAt = System.currentTimeMillis()
        )
    }
}
