package ru.windcompanion

import android.content.Context
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

object WindWork {
    private const val PERIODIC_NAME = "wind_refresh_30m"
    private const val INITIAL_NAME = "wind_refresh_now"

    fun start(context: Context) {
        val periodic = PeriodicWorkRequestBuilder<WindRefreshWorker>(30, TimeUnit.MINUTES)
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            PERIODIC_NAME, ExistingPeriodicWorkPolicy.KEEP, periodic
        )
        enqueueNow(context, ExistingWorkPolicy.KEEP)
    }

    /** Принудительное обновление (кнопка на экране). */
    fun refreshNow(context: Context) = enqueueNow(context, ExistingWorkPolicy.REPLACE)

    private fun enqueueNow(context: Context, policy: ExistingWorkPolicy) {
        val initial = OneTimeWorkRequestBuilder<WindRefreshWorker>().build()
        WorkManager.getInstance(context).enqueueUniqueWork(INITIAL_NAME, policy, initial)
    }
}
